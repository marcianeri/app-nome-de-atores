import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private httpClient: HttpClient) { }
  getPeople(){
    return this.httpClient.get('https://api.themoviedb.org/3/person/popular?api_key=73badb415401cf4ba2bb4a7ebcf6d15c&language=en-US&page=1');            
    }
  }
